//
//  AddViewController.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/5/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {

    @IBOutlet weak var botonAgregar: UIButton!
    
    @IBOutlet weak var miLabel: UILabel!
    
    @IBOutlet weak var botonCancelar: UIButton!
    
    @IBOutlet weak var miTexto: UITextField!
    
    var viewController: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        botonAgregar.aplicarDiseño()
        botonCancelar.setTitleColor(UIColor.tulip, for: .normal)
        self.view.backgroundColor = UIColor.mistyRose

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Agregar(_ sender: UIButton) {
        
        viewController.miArreglo.append(miTexto.text!)
        
        miLabel.text = "¡Se agrego a la lista!"
        viewController.misRecordatorios.reloadData()
    }
    
    @IBAction func Cancelar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
        
    }
    //Para quitar el teclado cuando se de clic en cualquier parte de la pantalla
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
