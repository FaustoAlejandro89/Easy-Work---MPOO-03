//
//  Colores.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/5/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import Foundation
import UIKit

extension UIColor{
    
    /*static let charcoal = UIColor().colorFromHex("3A405A")
     static let vistaBlue = UIColor().colorFromHex("858AE3")
     static let unbleachedSilk = UIColor().colorFromHex("F9DEC9")
     static let pastelPink = UIColor().colorFromHex("E9AFA3")
     static let mediumTaupe = UIColor().colorFromHex("685044")*/
    
    static let tulip = UIColor().colorFromHex("F48B94")
    static let mistyRose = UIColor().colorFromHex("FFE5E7")
    static let lemonYellow = UIColor().colorFromHex("FFED4C")
    //static let bluePigment = UIColor().colorFromHex("2D33AD")
    //static let middelRedPurple = UIColor().colorFromHex("0E1035")
    static let aereoBlue = UIColor().colorFromHex("D4F7EB")
    
    func colorFromHex (_ hex: String) -> UIColor{
        var hexString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if hexString.hasPrefix("#"){
            hexString.remove(at: hexString.startIndex)
        }
        
        if hexString.count != 6{
            return UIColor.black
        }
        
        var rgb: UInt32 = 0
        Scanner(string: hexString).scanHexInt32(&rgb)
        
        return UIColor.init(red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0, green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0, blue: CGFloat(rgb & 0x0000FF) / 255.0, alpha: 1.0)
    }
}
