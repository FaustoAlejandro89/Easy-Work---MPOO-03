//
//  ViewController.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/4/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import UIKit
import Lottie
import UserNotifications

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var misRecordatorios: UITableView!
    
    var miArreglo: [String] = []
    
    @IBOutlet weak var labelFecha: UILabel!
    
    @IBOutlet weak var botonIniciar: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var fecha = Date()
        var calendario = Calendar.current
        
        var dia = calendario.component (.day, from: fecha)
        var mes = calendario.component (.month, from: fecha)
        
        labelFecha.text = ("Fecha: \(dia) / \(mes)")
        
        //Color de la Primera vista (Item)
        self.view.backgroundColor = UIColor.aereoBlue
        
        botonIniciar.aplicarDiseño()
        
        //Mi view controller se hace responsable de mi tabla
        misRecordatorios.dataSource = self
        misRecordatorios.delegate = self
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]){(granted, error) in
            if granted == true {
                print ("Autorización correcta")
            }
            else{
                print("No existe autorización")
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
   
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            miArreglo.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //        etiqueta.text = alumnos[indexPath.row].nombre
        //        let cell = tablita.cellForRow(at: indexPath)
        
        let alertMenu = UIAlertController(title: "¿Terminaste tu tarea?", message: "Colocar marca", preferredStyle: .alert)
        
        let cancelarAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        let terminarAction = UIAlertAction(title: "Terminar", style: .default) { (action : UIAlertAction) in
            let celda = tableView.cellForRow(at: indexPath)
            
            
            if celda?.accessoryType.rawValue == 0{
                celda?.accessoryType = .checkmark
            }else{
                celda?.accessoryType = .none
            }
        }
        
        alertMenu.addAction(cancelarAction)
        alertMenu.addAction(terminarAction)
        
        present(alertMenu, animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return miArreglo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell()
        
        cell.textLabel?.text = miArreglo[indexPath.row]
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toAgregar"{
            let agregarView = segue.destination as? AddViewController
            agregarView?.viewController = self
        }
    }
    
}

