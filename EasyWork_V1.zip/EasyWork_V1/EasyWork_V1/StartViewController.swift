//
//  StartViewController.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/5/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import UIKit
import Lottie
import UserNotifications

class StartViewController: UIViewController, UNUserNotificationCenterDelegate{
    
    var miGif: String = "data"
    
    var animationView: AnimationView!
    
    @IBOutlet weak var labelTimer: UILabel!
    
    @IBOutlet weak var botonComenzar: UIButton!
    
    @IBOutlet weak var botonReset: UIButton!
    
    @IBOutlet weak var botonPausar: UIButton!
    
    @IBOutlet weak var botonConfigurar: UIButton!
    
    @IBOutlet weak var miMarco: UIImageView!
    
    var contador = 0
    
    var timer = Timer()
    
    var tiempoReposo: Int = 5
    
    var tiempoTrabajo: Int = 25
    
    let centralNotificaciones = UNUserNotificationCenter.current()
    
    let contenido = UNMutableNotificationContent()
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.aereoBlue
        
        //Mis animaciones
        iniciarAnimacion()
        
        botonComenzar.aplicarDiseño()
        
        botonConfigurar.setTitleColor(UIColor.tulip, for: .normal)
        
        botonPausar.setTitleColor(UIColor.tulip, for: .normal)
        
        botonReset.setTitleColor(UIColor.tulip, for: .normal)
    }
    

    func iniciarAnimacion(){
        
        //var animationView = AnimationView (name: miGif)
        animationView?.removeFromSuperview()
        animationView = AnimationView (name: miGif)
        
        animationView.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        animationView.center = self.view.center
        animationView.contentMode = .scaleAspectFill
        
        view.addSubview(animationView)
        animationView.loopMode = .loop
        animationView.play()
        
        /*if animationView.isAnimationPlaying{
            animationView.removeFromSuperview()
            print ("Se esta reproduciendo la imagen")
        }else{
            print ("NO esta activa la imagen")
        }*/
        
        
    }
    
    @IBAction func comenzar(_ sender: UIButton) {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(StartViewController.counter), userInfo: nil, repeats: true)
    }
    
    @objc func counter (){

        contenido.title = "TIEMPO TERMINADO"
        contenido.subtitle = "¡Es hora de descansar!"
        contenido.body = "Date 5 minutos de descanso"
        
        contador += 1
        
        labelTimer.text = String(contador)
        
        //DE 25 MIN SON 1500 SEGUNDOS 
        if contador == 5{
            
            //Para mandar la notificacacion aun adentro de la app
            centralNotificaciones.delegate = appDelegate
            //Cuando se va a lanzar la notificacion?
            let miTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
            
            //Peticion para lanzar la notificacion
            let miPeticion = UNNotificationRequest(identifier: "Minotificacion", content: contenido, trigger: miTrigger)
            centralNotificaciones.add(miPeticion){ (error) in
                if error != nil{
                    print ("Se creo correctamente la notificacion")
                }
                else{
                    print ("Se produjo un error con la notificacion")
                }
            }
        }
    }
    
    @IBAction func reset(_ sender: UIButton) {
        timer.invalidate()
        
        contador = 0
        
        labelTimer.text = ("0")
    }
    
    @IBAction func pausar(_ sender: UIButton) {
        timer.invalidate()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toEdit"{
            let editarView = segue.destination as? EditViewController
            editarView?.startViewController = self
        }
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
