//
//  EditViewController.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/5/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import UIKit

class EditViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var myPicker: UIPickerView!
    
    
    @IBOutlet weak var botonBack: UIButton!
    
    var startViewController: StartViewController!
    
    var misDatosPicker: [String] = [String]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.mistyRose
        
        self.myPicker.delegate = self
        self.myPicker.dataSource = self
        
        misDatosPicker = ["data", "office", "cloud", "hearts", "galaxy", "flowers", "dance", "elephant"]
        
        
        
        botonBack.setTitleColor(UIColor.tulip, for: .normal)
        

        // Do any additional setup after loading the view.
    }
    
    func edit(){
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return misDatosPicker.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return misDatosPicker[row]
    }

    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //print(misDatosPicker[row])
        startViewController.miGif = misDatosPicker[row]
        //startViewController.miGif.reloadData()
        startViewController.iniciarAnimacion()
        
        
        //viewController.misRecordatorios.reloadData()
        // This method is triggered whenever the user makes a change to the picker selection.
        // The parameter named row and component represents what was selected.
        
    }
    
    @IBAction func actionRegresar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
