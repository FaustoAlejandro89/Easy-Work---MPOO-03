//
//  Botones.swift
//  EasyWork_V1
//
//  Created by Fausto Alejandro Lopez on 6/5/19.
//  Copyright © 2019 Fausto Alejandro Lopez. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
    func aplicarDiseño() {
        self.backgroundColor = UIColor.tulip
        self.layer.cornerRadius = self.frame.height / 2
        self.setTitleColor(UIColor.white, for: .normal)
    }
}
